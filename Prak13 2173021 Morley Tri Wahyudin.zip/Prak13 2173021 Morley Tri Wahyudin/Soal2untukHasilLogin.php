<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }
        .result {
            font-size: 24px;
        }
        .success {
            color: black;
        }
        .failure {
            color: red;
        }
        a {
            color: blue;
            text-decoration: underline;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === 'admin' && $password === 'admin') {
            echo "<div class='berhasil'>Login berhasil!<br>Selamat datang, <b>admin</b>.</div>";
        } else {
            echo "<div class='hasilgagal'>Username : " . htmlspecialchars($username) . " TIDAK Terdaftar!</div>";
        }
        echo "<br><a href='Soal2.php'>kembali ke halaman login</a>";
    }
    ?>
</body>
</html>