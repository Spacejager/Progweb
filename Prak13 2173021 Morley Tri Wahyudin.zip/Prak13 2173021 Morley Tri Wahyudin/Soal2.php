<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .login-container {
            width: 300px;
            margin: 50px auto;
            border: 1px solid #ccc;
            padding: 10px;
        }
        .header {
            background-color: #000066;
            color: white;
            text-align: center;
            padding: 10px;
            font-size: 24px;
        }
        .footer {
            text-align: left;
            font-size: 12px;
            margin-top: 10px;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 5px;
            margin-top: 5px;
        }
        input[type="submit"] {
            margin-top: 10px;
            padding: 5px 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="header">Login</div>
        <form method="post" action="Soal2UntukHasilLogin.php">
            <label>Username</label>
            <input type="text" name="username" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <input type="submit" name="login" value="login">
        </form>
        <div class="footer">&copy; UKM2014 <br> Name-NRP&copy;</div>
    </div>
</body>
</html>