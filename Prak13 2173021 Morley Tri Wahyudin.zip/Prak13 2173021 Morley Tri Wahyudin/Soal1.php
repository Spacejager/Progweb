<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>2173021 Morley Tri Wahyudin</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
        }
        .error {
            color: red;
        }
        .success {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <table>
            <tr>
                <th colspan="2">Add profile</th>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"></td>
            </tr>
            <tr>
                <td>Position</td>
                <td>
                    <select name="position">
                        <option value="Senior Programmer" <?php echo (!isset($_POST['position']) || $_POST['position'] == 'Senior Programmer') ? 'selected' : ''; ?>>Senior Programmer</option>
                        <option value="Programmer" <?php echo (isset($_POST['position']) && $_POST['position'] == 'Programmer') ? 'selected' : ''; ?>>Programmer</option>
                        <option value="Junior Programmer" <?php echo (isset($_POST['position']) && $_POST['position'] == 'Junior Programmer') ? 'selected' : ''; ?>>Junior Programmer</option>
                        <option value="System Analyst" <?php echo (isset($_POST['position']) && $_POST['position'] == 'System Analyst') ? 'selected' : ''; ?>>System Analyst</option>
                        <option value="Senior Analyst" <?php echo (isset($_POST['position']) && $_POST['position'] == 'Senior Analyst') ? 'selected' : ''; ?>>Senior Analyst</option>
                        <option value="Junior Analyst" <?php echo (isset($_POST['position']) && $_POST['position'] == 'Junior Analyst') ? 'selected' : ''; ?>>Junior Analyst</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" value=""></td>
            </tr>
            <tr>
                <td>Confirm Password</td>
                <td><input type="password" name="confirm_password" value=""></td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" name="reset" value="Reset">
                    <input type="submit" name="save" value="Save">
                </td>
            </tr>
        </table>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['reset'])) {
            // Reset form by clearing POST data (browser will handle resetting the form)
        } elseif (isset($_POST['save'])) {
            $name = trim($_POST['name'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            $position = $_POST['position'] ?? 'Senior Programmer';

            $errors = [];

            if (empty($name)) {
                $errors[] = "Input Nama belum di isi!";
            }
            if (empty($password)) {
                $errors[] = "Input Password belum di isi!";
            }
            if (empty($confirm_password)) {
                $errors[] = "Input Confirm Password belum di isi!";
            }
            if ($password !== $confirm_password && !empty($password) && !empty($confirm_password)) {
                $errors[] = "Password dan Confirm Password belum sama!";
            }

            if (!empty($errors)) {
                foreach ($errors as $error) {
                    echo "<p class='error'>$error</p>";
                }
            } else {
                echo "<div class='success'><table><tr><th colspan='2'>Data yang Anda Masukkan!</th></tr>";
                echo "<tr><td>Name</td><td>: " . htmlspecialchars($name) . "</td></tr>";
                echo "<tr><td>Position</td><td>: " . htmlspecialchars($position) . "</td></tr>";
                echo "<tr><td colspan='2'><a href='?'>back</a></td></tr></table></div>";
            }
        }
    }
    ?>
</body>
</html>