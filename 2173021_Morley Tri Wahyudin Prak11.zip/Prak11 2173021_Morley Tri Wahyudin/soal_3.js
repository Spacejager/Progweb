$(document).ready(function () {
    let redIndex = -1; 

    
    $(".box").click(function () {
        
        $(".box").css("background-color", "white");

       
        $(this).css("background-color", "red");

        
        redIndex = $(".box").index(this);
    });

    
    $("#change-color").click(function () {
        if (redIndex !== -1) { 
            $(".box").each(function (index) {
                if (index < redIndex) {
                    $(this).css("background-color", "yellow");
                }
            });
        }
    });
});