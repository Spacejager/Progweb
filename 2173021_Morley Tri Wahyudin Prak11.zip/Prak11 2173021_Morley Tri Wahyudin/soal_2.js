$(document).ready(function () {
    const inputField = $("#inputField");
    const nameContainer = $("#nameContainer");
  

    $("#addButton").click(function () {
      const name = inputField.val().trim();
      if (name) {
        $("<div></div>")
          .addClass("name")
          .text(name)
          .appendTo(nameContainer);
        inputField.val(""); 
      }
    });
  

    $("#searchButton").click(function () {
      const searchText = inputField.val().trim().toLowerCase();
      $(".name").each(function () {
        const nameText = $(this).text().toLowerCase();
        if (nameText.includes(searchText) && searchText) {
          $(this).addClass("highlight");
        } else {
          $(this).removeClass("highlight");
        }
      });
    });
  });