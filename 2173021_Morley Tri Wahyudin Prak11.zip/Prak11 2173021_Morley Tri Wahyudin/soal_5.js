$(document).ready(function () {
    const searchField = $("#searchField");
    
    searchField.on("input", function () {
      const searchText = searchField.val().toLowerCase();
      
      $(".company-item").each(function () {
        const companyName = $(this).text().toLowerCase();
        if (companyName.includes(searchText) && searchText) {
          $(this).addClass("highlight");
        } else {
          $(this).removeClass("highlight");
        }
      });
    });
  });