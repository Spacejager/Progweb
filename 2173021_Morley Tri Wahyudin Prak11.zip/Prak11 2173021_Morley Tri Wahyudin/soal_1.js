$(document).ready(function () {
  
    $("li.item ul").hide();
  
 
    $("li.item").hover(
      function () {
        $(this).find("ul").stop(true, true).slideDown();
      },
      function () {
        $(this).find("ul").stop(true, true).slideUp();
      }
    );
  });